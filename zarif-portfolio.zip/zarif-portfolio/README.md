# Zarif Portfolio

A multi-page responsive portfolio built with HTML, CSS and vanilla JavaScript.

## Pages
- Home
- About
- Skills
- Projects
- Experience
- Achievements
- Contact

## Run locally
Open `index.html` directly, or use VS Code Live Server.

## Publish with GitHub Pages
1. Put all files in your repository root.
2. Commit and push to GitHub.
3. GitHub repo → Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: `main`, folder: `/root`.
6. Save.

## Important before publishing
Edit `contact.html` and replace:
- LinkedIn placeholder
- Email placeholder
- Optional phone
- CV/resume URL

The contact form UI is included, but static GitHub Pages cannot receive form submissions by itself. Connect it to Formspree, Web3Forms, EmailJS, or your own backend.
