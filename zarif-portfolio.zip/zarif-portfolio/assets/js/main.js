
const body = document.body;
const themeBtn = document.querySelector('[data-theme]');
const menuBtn = document.querySelector('[data-menu]');
const navLinks = document.querySelector('.nav-links');

const savedTheme = localStorage.getItem('portfolio-theme');
if(savedTheme === 'light') body.classList.add('light');

function syncThemeIcon(){
  if(themeBtn) themeBtn.textContent = body.classList.contains('light') ? '☀' : '☾';
}
syncThemeIcon();

themeBtn?.addEventListener('click',()=>{
  body.classList.toggle('light');
  localStorage.setItem('portfolio-theme', body.classList.contains('light') ? 'light' : 'dark');
  syncThemeIcon();
});

menuBtn?.addEventListener('click',()=> navLinks?.classList.toggle('open'));

const observer = new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      entry.target.classList.add('show');
      observer.unobserve(entry.target);
    }
  });
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

document.querySelectorAll('[data-filter]').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('[data-filter]').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const filter = btn.dataset.filter;
    document.querySelectorAll('[data-project]').forEach(card=>{
      card.style.display = filter === 'all' || card.dataset.project === filter ? '' : 'none';
    });
  });
});

const year = document.querySelector('[data-year]');
if(year) year.textContent = new Date().getFullYear();

const form = document.querySelector('#contactForm');
form?.addEventListener('submit',e=>{
  e.preventDefault();
  const status = document.querySelector('#formStatus');
  status.textContent = 'Message prepared. Connect this form to Formspree, Web3Forms, or your backend to receive submissions.';
});
